Mỗi file .json trong thư mục này
- Dưới 200 LOC (Lines of Code)
- Là file .json đã được nén (minified).
