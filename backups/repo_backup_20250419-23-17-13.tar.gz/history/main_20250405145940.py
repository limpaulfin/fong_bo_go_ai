from src.core.keyboard_handler import KeyboardHandler
from src.core.clipboard_manager import ClipboardManager
from src.utils.token_tracker import TokenUsageTracker
from src.utils.logger import APILogger
from src.ui.tray_icon import SystemTrayIcon
import time
import os

def main():
    # Khởi tạo các components
    keyboard_handler = KeyboardHandler()
    clipboard_manager = ClipboardManager()
    token_tracker = TokenUsageTracker()
    api_logger = APILogger()

    # Khởi tạo system tray
    def on_quit():
        keyboard_handler.stop_listening()
        os._exit(0)

    tray_icon = SystemTrayIcon(on_quit)

    try:
        print("Script đang chạy...")

        # Bắt đầu listening keyboard
        keyboard_handler.start_listening()

        # Chạy system tray
        tray_icon.run_detached()

        # Main loop
        while True:
            time.sleep(0.3)
            if keyboard_handler.should_scan:
                # Xử lý text correction
                print(f"Trigger source: {keyboard_handler.trigger_source}")

                # Hiển thị thông báo debug đơn giản để xác nhận chức năng
                print("="*50)
                print(f"Đã kích hoạt chức năng thông qua: {keyboard_handler.trigger_source}")
                if keyboard_handler.trigger_source == 'double_backslash':
                    print("Chức năng: Auto-correct với RAG context")
                elif keyboard_handler.trigger_source == 'double_right_shift':
                    print("Chức năng: Auto-correct không có RAG context")
                elif keyboard_handler.trigger_source == 'scroll_lock':
                    print("Chức năng: Auto-correct cơ bản")
                print("Sẽ bổ sung đầy đủ chức năng xử lý văn bản trong phiên bản sau")
                print("="*50)

                keyboard_handler.should_scan = False

    except KeyboardInterrupt:
        keyboard_handler.stop_listening()
        tray_icon.stop()
        print("\nĐã dừng script.")
    except Exception as e:
        print(f"Lỗi không mong muốn: {str(e)}")
        tray_icon.stop()

if __name__ == "__main__":
    main()
