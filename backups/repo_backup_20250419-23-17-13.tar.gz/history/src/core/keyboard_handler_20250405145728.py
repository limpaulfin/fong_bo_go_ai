from pynput import keyboard
from pynput.keyboard import Key
import time
from config.settings import DOUBLE_SPACE_THRESHOLD

class KeyboardHandler:
    def __init__(self):
        self.should_scan = False
        self.last_space_time = 0
        self.space_count = 0
        self.last_backslash_time = 0
        self.last_right_shift_time = 0
        self.trigger_source = None

    def on_press(self, key):
        try:
            print(f"Phím được nhấn: {key}")

            if key == Key.shift_r:
                current_time = time.time()
                time_diff = current_time - self.last_right_shift_time
                print(f"Right Shift: time_diff = {time_diff}")

                if time_diff < DOUBLE_SPACE_THRESHOLD:
                    self.should_scan = True
                    self.trigger_source = 'double_right_shift'
                    print("Double Right Shift được kích hoạt!")

                self.last_right_shift_time = current_time

            elif isinstance(key, keyboard.KeyCode) and key.char == '\\':
                current_time = time.time()
                time_diff = current_time - self.last_backslash_time
                print(f"Backslash: time_diff = {time_diff}")

                if time_diff < DOUBLE_SPACE_THRESHOLD:
                    self.should_scan = True
                    self.trigger_source = 'double_backslash'
                    print("Double Backslash được kích hoạt!")

                self.last_backslash_time = current_time

            elif key == Key.scroll_lock:
                self.should_scan = True
                self.trigger_source = 'scroll_lock'
                print("Scroll Lock được kích hoạt!")

            else:
                if self.space_count > 0:
                    self.space_count = 0

        except AttributeError as e:
            print(f"AttributeError: {e}")
            pass

    def start_listening(self):
        self.listener = keyboard.Listener(on_press=self.on_press)
        self.listener.start()
        print("Bắt đầu lắng nghe bàn phím...")

    def stop_listening(self):
        if hasattr(self, 'listener'):
            self.listener.stop()
            print("Đã dừng lắng nghe bàn phím.")
