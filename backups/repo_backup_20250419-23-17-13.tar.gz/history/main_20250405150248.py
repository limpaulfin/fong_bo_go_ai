from src.core.keyboard_handler import KeyboardHandler
from src.core.clipboard_manager import ClipboardManager
from src.utils.token_tracker import TokenUsageTracker
from src.utils.logger import APILogger
from src.ui.tray_icon import SystemTrayIcon
import time
import os
import pyperclip

def main():
    # Khởi tạo các components
    keyboard_handler = KeyboardHandler()
    clipboard_manager = ClipboardManager()
    token_tracker = TokenUsageTracker()
    api_logger = APILogger()

    # Khởi tạo system tray
    def on_quit():
        keyboard_handler.stop_listening()
        os._exit(0)

    tray_icon = SystemTrayIcon(on_quit)

    try:
        print("Script đang chạy...")

        # Bắt đầu listening keyboard
        keyboard_handler.start_listening()

        # Chạy system tray
        tray_icon.run_detached()

        # Main loop
        while True:
            time.sleep(0.3)
            if keyboard_handler.should_scan:
                # Xử lý text correction
                print(f"Trigger source: {keyboard_handler.trigger_source}")

                # Hiển thị thông báo debug
                print("="*50)
                print(f"Đã kích hoạt chức năng thông qua: {keyboard_handler.trigger_source}")

                if keyboard_handler.trigger_source == 'double_backslash':
                    print("Chức năng: Auto-correct với RAG context")
                elif keyboard_handler.trigger_source == 'double_right_shift':
                    print("Chức năng: Auto-correct không có RAG context")
                elif keyboard_handler.trigger_source == 'scroll_lock':
                    print("Chức năng: Auto-correct cơ bản")

                # Xử lý văn bản
                try:
                    # Lưu trạng thái clipboard
                    original_clipboard = pyperclip.paste()

                    # Lấy văn bản đã chọn hoặc từ vị trí con trỏ đến đầu dòng
                    selected_text, has_selection = clipboard_manager.get_selected_text(keyboard_handler.trigger_source)

                    if selected_text and selected_text.strip():
                        print(f"Văn bản gốc: '{selected_text}'")
                        print("Chức năng text correction đang được triển khai...")

                        # Đây là nơi sẽ gọi API để sửa lỗi văn bản
                        # Hiện tại chỉ trả về văn bản gốc có thêm thông báo
                        corrected_text = f"{selected_text} [Đã kích hoạt thông qua {keyboard_handler.trigger_source}]"

                        print(f"Văn bản đã sửa: '{corrected_text}'")

                        # Thay thế văn bản cũ bằng văn bản đã sửa
                        pyperclip.copy(corrected_text)
                        time.sleep(0.1)

                        # Thực hiện paste
                        if has_selection:
                            # Nếu đã có selection
                            clipboard_manager.keyboard.press(clipboard_manager.keyboard.ctrl)
                            clipboard_manager.keyboard.tap('v')
                            clipboard_manager.keyboard.release(clipboard_manager.keyboard.ctrl)
                        else:
                            # Select từ vị trí hiện tại đến đầu dòng
                            clipboard_manager.keyboard.press(clipboard_manager.keyboard.shift)
                            clipboard_manager.keyboard.press(clipboard_manager.keyboard.home)
                            clipboard_manager.keyboard.release(clipboard_manager.keyboard.home)
                            clipboard_manager.keyboard.release(clipboard_manager.keyboard.shift)
                            time.sleep(0.1)

                            # Paste
                            clipboard_manager.keyboard.press(clipboard_manager.keyboard.ctrl)
                            clipboard_manager.keyboard.tap('v')
                            clipboard_manager.keyboard.release(clipboard_manager.keyboard.ctrl)

                except Exception as e:
                    print(f"Lỗi khi xử lý văn bản: {str(e)}")

                finally:
                    # Khôi phục clipboard
                    time.sleep(0.2)
                    try:
                        pyperclip.copy(original_clipboard)
                    except Exception as e:
                        print(f"Lỗi khi khôi phục clipboard: {str(e)}")

                print("="*50)
                keyboard_handler.should_scan = False

    except KeyboardInterrupt:
        keyboard_handler.stop_listening()
        tray_icon.stop()
        print("\nĐã dừng script.")
    except Exception as e:
        print(f"Lỗi không mong muốn: {str(e)}")
        tray_icon.stop()

if __name__ == "__main__":
    main()
