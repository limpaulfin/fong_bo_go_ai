
# ghi chú 2024-11-03

Các files `.md` trong thư mục `rag_context` là các file chứa context cho bộ gõ AI (ngoại trừ file `README.md` này).
Nếu bạn không muốn sử dụng context, bạn có thể bỏ qua thư mục này hoặc move các file đó vào thư mục `_ignore`

