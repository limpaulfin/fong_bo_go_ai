# Details

Date : 2024-12-12 11:25:17

Directory f:\\Dropbox\\dev\\python_bo_go_ai

Total : 15 files,  941 codes, 100 comments, 242 blanks, all 1283 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.context.md](/.context.md) | Markdown | 141 | 0 | 32 | 173 |
| [README.md](/README.md) | Markdown | 62 | 0 | 23 | 85 |
| [config/settings.py](/config/settings.py) | Python | 11 | 3 | 4 | 18 |
| [detect_device.py](/detect_device.py) | Python | 10 | 4 | 4 | 18 |
| [main.py](/main.py) | Python | 35 | 8 | 11 | 54 |
| [my_prompt.md](/my_prompt.md) | Markdown | 25 | 0 | 9 | 34 |
| [rag_context/README.md](/rag_context/README.md) | Markdown | 3 | 0 | 4 | 7 |
| [requirements.txt](/requirements.txt) | pip requirements | 8 | 3 | 3 | 14 |
| [run_bo_go_ai.bat](/run_bo_go_ai.bat) | Batch | 3 | 0 | 1 | 4 |
| [run_main.py](/run_main.py) | Python | 504 | 75 | 117 | 696 |
| [src/core/clipboard_manager.py](/src/core/clipboard_manager.py) | Python | 38 | 2 | 6 | 46 |
| [src/core/keyboard_handler.py](/src/core/keyboard_handler.py) | Python | 45 | 1 | 14 | 60 |
| [src/ui/tray_icon.py](/src/ui/tray_icon.py) | Python | 15 | 1 | 5 | 21 |
| [src/utils/logger.py](/src/utils/logger.py) | Python | 28 | 0 | 4 | 32 |
| [src/utils/token_tracker.py](/src/utils/token_tracker.py) | Python | 13 | 3 | 5 | 21 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)