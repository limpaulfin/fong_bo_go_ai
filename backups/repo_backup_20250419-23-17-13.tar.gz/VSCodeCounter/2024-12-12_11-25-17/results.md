# Summary

Date : 2024-12-12 11:25:17

Directory f:\\Dropbox\\dev\\python_bo_go_ai

Total : 15 files,  941 codes, 100 comments, 242 blanks, all 1283 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 9 | 699 | 97 | 170 | 966 |
| Markdown | 4 | 231 | 0 | 68 | 299 |
| pip requirements | 1 | 8 | 3 | 3 | 14 |
| Batch | 1 | 3 | 0 | 1 | 4 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 15 | 941 | 100 | 242 | 1,283 |
| . (Files) | 8 | 788 | 90 | 200 | 1,078 |
| config | 1 | 11 | 3 | 4 | 18 |
| rag_context | 1 | 3 | 0 | 4 | 7 |
| src | 5 | 139 | 7 | 34 | 180 |
| src\\core | 2 | 83 | 3 | 20 | 106 |
| src\\ui | 1 | 15 | 1 | 5 | 21 |
| src\\utils | 2 | 41 | 3 | 9 | 53 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)